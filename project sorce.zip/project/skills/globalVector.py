from .skillAliases import skills

GLOBAL_SKILL_VECTOR = sorted(skills.keys())
