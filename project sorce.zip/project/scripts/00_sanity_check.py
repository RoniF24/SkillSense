from src.config import DATA_DIR, RAW_DIR, SYNTH_DIR, PROC_DIR

def main():
    print("DATA_DIR:", DATA_DIR)
    print("RAW_DIR:", RAW_DIR)
    print("SYNTH_DIR:", SYNTH_DIR)
    print("PROC_DIR:", PROC_DIR)

if __name__ == "__main__":
    main()
