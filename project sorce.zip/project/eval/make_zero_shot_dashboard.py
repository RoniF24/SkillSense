from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional

try:
    import matplotlib.pyplot as plt
except Exception as e:
    raise RuntimeError("matplotlib is required. Install: pip install matplotlib") from e


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    rows: List[Dict[str, str]] = []
    with path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append({k: (v if v is not None else "") for k, v in r.items()})
    return rows


def parse_float(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if math.isnan(v) or math.isinf(v):
            return default
        return v
    except Exception:
        return default


def count_jsonl_lines(path: Path) -> int:
    try:
        with path.open("r", encoding="utf-8") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def infer_dataset_name(run_dir: Path) -> str:
    for p in run_dir.parts:
        if p.startswith("dataset__"):
            return p.replace("dataset__", "")
    return run_dir.parent.name


def load_overall_metrics(run_dir: Path) -> Dict[str, Dict[str, float]]:
    rows = read_csv_rows(run_dir / "overall_metrics.csv")
    out: Dict[str, Dict[str, float]] = {}

    for r in rows:
        mode = (r.get("mode") or "").lower()
        key: Optional[str] = None

        # order matters
        if "implicit" in mode or "implicit_only" in mode or "0.5_only" in mode:
            key = "implicit"
        elif "explicit" in mode or "1.0" in mode or ">=1.0" in mode:
            key = "explicit"
        elif "any_evidence" in mode or "any" in mode or ">=0.5" in mode or "0.5_or_1.0" in mode:
            key = "any"

        if not key:
            continue

        out[key] = {
            "precision": parse_float(r.get("precision"), 0.0),
            "recall": parse_float(r.get("recall"), 0.0),
            "f1": parse_float(r.get("f1"), 0.0),
            "tp": parse_float(r.get("tp"), 0.0),
            "fp": parse_float(r.get("fp"), 0.0),
            "fn": parse_float(r.get("fn"), 0.0),
        }
    return out


def load_per_skill_f1(run_dir: Path, mode: str) -> List[Tuple[str, float]]:
    mode = mode.lower().strip()
    if mode == "any":
        path = run_dir / "per_skill__any_evidence__f1.csv"
    elif mode == "implicit":
        path = run_dir / "per_skill__implicit_only__f1.csv"
    elif mode == "explicit":
        path = run_dir / "per_skill__explicit_only__f1.csv"
    else:
        raise ValueError("mode must be: any/implicit/explicit")

    rows = read_csv_rows(path)
    items: List[Tuple[str, float]] = []
    for r in rows:
        s = (r.get("skill") or "").strip()
        if not s:
            continue
        items.append((s, parse_float(r.get("f1"), 0.0)))
    return items


def count_errors(run_dir: Path, mode: str) -> Tuple[int, int]:
    mode = mode.lower().strip()
    if mode == "any":
        path = run_dir / "errors__any_evidence__fp_fn.csv"
    elif mode == "implicit":
        path = run_dir / "errors__implicit_only__fp_fn.csv"
    elif mode == "explicit":
        path = run_dir / "errors__explicit_only__fp_fn.csv"
    else:
        raise ValueError("mode must be: any/implicit/explicit")

    rows = read_csv_rows(path)
    fp = sum(1 for r in rows if (r.get("type") or "").upper() == "FP")
    fn = sum(1 for r in rows if (r.get("type") or "").upper() == "FN")
    return fp, fn


def top_bottom(items: List[Tuple[str, float]], k: int = 5) -> Tuple[List[Tuple[str, float]], List[Tuple[str, float]]]:
    if not items:
        return [], []
    items_desc = sorted(items, key=lambda x: x[1], reverse=True)
    topk = items_desc[:k]
    bottomk = sorted(items_desc, key=lambda x: x[1])[:k]
    return topk, bottomk


def make_zero_shot_dashboard(run_dir: Path, out_name: str) -> Path:
    run_dir = Path(run_dir)
    if not run_dir.exists():
        raise FileNotFoundError(f"run_dir does not exist: {run_dir}")

    dataset = infer_dataset_name(run_dir)
    samples = count_jsonl_lines(run_dir / "preds.jsonl")

    overall = load_overall_metrics(run_dir)
    exp = overall.get("explicit")
    imp = overall.get("implicit")
    any_m = overall.get("any")

    # Per-skill: show Any + Implicit (כי זה הכי חשוב ל-zero-shot)
    per_any = load_per_skill_f1(run_dir, "any")
    per_imp = load_per_skill_f1(run_dir, "implicit")

    top_any, bot_any = top_bottom(per_any, 5)
    top_imp, bot_imp = top_bottom(per_imp, 5)

    fp_any, fn_any = count_errors(run_dir, "any")
    fp_imp, fn_imp = count_errors(run_dir, "implicit")

    fig = plt.figure(figsize=(16, 12), dpi=120)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.1, 1.1], width_ratios=[1.05, 1.0])

    ax_text = fig.add_subplot(gs[0, 0])
    ax_micro = fig.add_subplot(gs[0, 1])
    ax_any_top = fig.add_subplot(gs[1, 0])
    ax_any_bot = fig.add_subplot(gs[1, 1])
    ax_imp_top = fig.add_subplot(gs[2, 0])
    ax_imp_bot = fig.add_subplot(gs[2, 1])

    fig.suptitle(f"Dashboard — zero_shot | dataset: {dataset}", fontsize=22, fontweight="bold", y=0.985)

    # Summary
    ax_text.axis("off")

    def fmt_block(name: str, m: Optional[Dict[str, float]]) -> str:
        if not m:
            return f"- {name}: (missing)"
        return (
            f"- {name}: P={m['precision']:.3f}  R={m['recall']:.3f}  F1={m['f1']:.3f}  "
            f"(TP/FP/FN={int(m['tp'])}/{int(m['fp'])}/{int(m['fn'])})"
        )

    lines = [
        "Summary",
        f"- Run dir: {run_dir.name}",
        f"- Samples evaluated: {samples}",
        "",
        "Micro Metrics",
        fmt_block("Explicit (>=1.0)", exp),
        fmt_block("Implicit (==0.5)", imp),
        fmt_block("Any (>=0.5)", any_m),
        "",
        f"Errors Any: FP={fp_any} | FN={fn_any}",
        f"Errors Implicit: FP={fp_imp} | FN={fn_imp}",
    ]
    ax_text.text(0.0, 1.0, "\n".join(lines), va="top", ha="left", fontsize=12)

    # Micro plot (3 series)
    ax_micro.set_title("Micro metrics (Explicit / Implicit / Any)", fontsize=16, fontweight="bold")
    labels = ["PRECISION", "RECALL", "F1"]
    x = list(range(len(labels)))

    series: List[List[float]] = []
    legends: List[str] = []

    if exp:
        series.append([exp["precision"], exp["recall"], exp["f1"]])
        legends.append("Explicit (>=1.0)")
    if imp:
        series.append([imp["precision"], imp["recall"], imp["f1"]])
        legends.append("Implicit (==0.5)")
    if any_m:
        series.append([any_m["precision"], any_m["recall"], any_m["f1"]])
        legends.append("Any (>=0.5)")

    if not series:
        ax_micro.text(0.5, 0.5, "overall_metrics.csv missing/empty", ha="center", va="center")
        ax_micro.set_xticks([]); ax_micro.set_yticks([])
    else:
        n = len(series)
        total_width = 0.8
        bar_w = total_width / n
        center_offset = (n - 1) / 2.0

        for idx, vals in enumerate(series):
            offset = (idx - center_offset) * bar_w
            xpos = [i + offset for i in x]
            ax_micro.bar(xpos, vals, width=bar_w)

        ax_micro.set_ylim(0.0, 1.05)
        ax_micro.set_xticks(x)
        ax_micro.set_xticklabels(labels)
        ax_micro.legend(legends, loc="upper right")

    # Any top/bottom
    ax_any_top.set_title("Top 5 skills by F1 (Any >=0.5)", fontsize=15, fontweight="bold")
    if not top_any:
        ax_any_top.axis("off")
        ax_any_top.text(0.5, 0.5, "Missing per_skill__any_evidence__f1.csv", ha="center", va="center")
    else:
        sk = [s for s, _ in top_any]
        f1s = [v for _, v in top_any]
        ax_any_top.barh(list(reversed(sk)), list(reversed(f1s)))
        ax_any_top.set_xlim(0.0, 1.05)
        ax_any_top.set_xlabel("F1")

    ax_any_bot.set_title("Bottom 5 skills by F1 (Any >=0.5)", fontsize=15, fontweight="bold")
    if not bot_any:
        ax_any_bot.axis("off")
        ax_any_bot.text(0.5, 0.5, "Missing per_skill__any_evidence__f1.csv", ha="center", va="center")
    else:
        sk = [s for s, _ in bot_any]
        f1s = [v for _, v in bot_any]
        ax_any_bot.barh(list(reversed(sk)), list(reversed(f1s)))
        ax_any_bot.set_xlim(0.0, 1.05)
        ax_any_bot.set_xlabel("F1")

    # Implicit top/bottom
    ax_imp_top.set_title("Top 5 skills by F1 (Implicit ==0.5)", fontsize=15, fontweight="bold")
    if not top_imp:
        ax_imp_top.axis("off")
        ax_imp_top.text(0.5, 0.5, "Missing per_skill__implicit_only__f1.csv", ha="center", va="center")
    else:
        sk = [s for s, _ in top_imp]
        f1s = [v for _, v in top_imp]
        ax_imp_top.barh(list(reversed(sk)), list(reversed(f1s)))
        ax_imp_top.set_xlim(0.0, 1.05)
        ax_imp_top.set_xlabel("F1")

    ax_imp_bot.set_title("Bottom 5 skills by F1 (Implicit ==0.5)", fontsize=15, fontweight="bold")
    if not bot_imp:
        ax_imp_bot.axis("off")
        ax_imp_bot.text(0.5, 0.5, "Missing per_skill__implicit_only__f1.csv", ha="center", va="center")
    else:
        sk = [s for s, _ in bot_imp]
        f1s = [v for _, v in bot_imp]
        ax_imp_bot.barh(list(reversed(sk)), list(reversed(f1s)))
        ax_imp_bot.set_xlim(0.0, 1.05)
        ax_imp_bot.set_xlabel("F1")

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    out_path = run_dir / out_name
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True, help="Path to run__latest directory")
    ap.add_argument("--out_name", default="dashboard__zero_shot.png", help="Output file name (inside run_dir)")
    args = ap.parse_args()

    out = make_zero_shot_dashboard(Path(args.run_dir), args.out_name)
    print(f"Saved: {out.resolve()}")


if __name__ == "__main__":
    main()
